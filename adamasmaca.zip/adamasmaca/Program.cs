﻿using System;
using System.Collections.Generic;

class HangmanGame
{
    static void Main()
    {
        // Cities list
        List<string> cities = new List<string> { "Istanbul", "Bursa", "Adana", "Antalya", "Gaziantep", "Sanliurfa" };
        Random rand = new Random();
        string selectedCity = cities[rand.Next(cities.Count)].ToUpper();

        char[] guessedCity = new string('_', selectedCity.Length).ToCharArray();
        int lives = 6;
        HashSet<char> guessedLetters = new HashSet<char>();

        while (lives > 0)
        {
            Console.Clear();
            Console.WriteLine("City to guess: " + new string(guessedCity));
            Console.WriteLine("Lives: " + lives);
            Console.Write("Guess a letter: ");
            char guess = Char.ToUpper(Console.ReadLine()[0]);

            if (guessedLetters.Contains(guess))
            {
                Console.WriteLine("You already guessed that letter.");
                continue;
            }

            guessedLetters.Add(guess);

            if (selectedCity.Contains(guess))
            {
                for (int i = 0; i < selectedCity.Length; i++)
                {
                    if (selectedCity[i] == guess)
                    {
                        guessedCity[i] = guess;
                    }
                }
            }
            else
            {
                lives--;
                Console.WriteLine("Wrong guess! Lives left: " + lives);
            }

            if (new string(guessedCity) == selectedCity)
            {
                Console.WriteLine("Congratulations! You guessed the city: " + selectedCity);
                break;
            }
        }

        if (lives == 0)
        {
            Console.WriteLine("Game over! The city was: " + selectedCity);
        }
    }
}
